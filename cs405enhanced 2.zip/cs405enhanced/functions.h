#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <iostream>
#include <string>
#include <vector>
#include <sqlite3.h>

// Function prototypes
void checkUserPermissionAccess(sqlite3* db);
void displayInfo();
void customerChoice();
void sub80484c0(sqlite3* db);
void createTable(sqlite3* db); // Declare createTable function
void insertData(sqlite3* db);  // Declare insertData function
void addUser(sqlite3* db, const std::string& username, const std::string& permission);
void viewUsers(sqlite3* db);
void updateUser(sqlite3* db, const std::string& username, const std::string& newPermission);
void deleteUser(sqlite3* db, const std::string& username);
bool isValidPermission(const std::string& input);

#endif // FUNCTIONS_H
