#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <sqlite3.h>

// Function prototypes
void checkUserPermissionAccess(sqlite3* db);
void displayInfo();
void createTable(sqlite3* db);
void insertData(sqlite3* db);
void viewTable(sqlite3* db);
void updateUser(sqlite3* db, const std::string& username, const std::string& newPermission);
void viewUsers(sqlite3* db) ;
void deleteTable(sqlite3* db);
bool isValidPermission(const std::string& input);

int main() {
    sqlite3* db;
    int rc = sqlite3_open(":memory:", &db); // Use in-memory database
    if (rc) {
        std::cerr << "Can't open database: " << sqlite3_errmsg(db) << std::endl;
        return 1;
    }
    std::cout << "Opened database successfully" << std::endl;

    // Function calls
    while (true) {
        checkUserPermissionAccess(db);
        std::string choice;
        std::cout << "Do you want to perform another action? (yes/no): ";
        std::cin >> choice;
        if (choice != "yes")
            break;
    }

    sqlite3_close(db);
    return 0;
}

bool isValidPermission(const std::string& input) {
    std::vector<std::string> validPermissions = {"admin", "user", "guest"};
    return std::find(validPermissions.begin(), validPermissions.end(), input) != validPermissions.end();
}

void checkUserPermissionAccess(sqlite3* db) {
    std::string permission;
    std::cout << "Enter permission access (admin/user/guest): ";
    std::cin >> permission;

    // Validate user input
    while (!isValidPermission(permission)) {
        std::cout << "Invalid permission. Please enter admin, user, or guest: ";
        std::cin >> permission;
    }

    // Perform action based on user's permission
    if (permission == "admin") {
        displayInfo();
        createTable(db);
        insertData(db);
        viewTable(db);
        deleteTable(db);
    } else if (permission == "user") {
        // Call user function here
        displayInfo();
        createTable(db);
        insertData(db);
        updateUser(db, "admin", "user");
        viewUsers(db);
        viewTable(db);
        deleteTable(db);

    } else if (permission == "guest") {
        // Call guest function here
        displayInfo();
        createTable(db);
        insertData(db);
        viewTable(db);
        deleteTable(db);
    }
}

void displayInfo() {
    std::cout << "Displaying Info..." << std::endl;
}
void updateUser(sqlite3* db, const std::string& username, const std::string& newPermission) {
    if (!isValidPermission(newPermission)) {
        std::cout << "Invalid permission." << std::endl;
        return;
    }

    sqlite3_stmt* stmt;
    const char* sql = "UPDATE users SET permission = ? WHERE username = ?;";
    sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);
    sqlite3_bind_text(stmt, 1, newPermission.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, username.c_str(), -1, SQLITE_STATIC);

    if (sqlite3_step(stmt) != SQLITE_DONE) {
        std::cerr << "Error updating user: " << sqlite3_errmsg(db) << std::endl;
    } else {
        std::cout << "User updated successfully." << std::endl;
    }

    sqlite3_finalize(stmt);
}

void createTable(sqlite3* db) {
    std::string tableName;
    std::cout << "Enter table name: ";
    std::cin >> tableName;

    std::string sql = "CREATE TABLE IF NOT EXISTS " + tableName + " (id INTEGER PRIMARY KEY, name TEXT);";
    char* errMsg = nullptr;
    int rc = sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &errMsg);
    if (rc != SQLITE_OK) {
        std::cerr << "SQL error: " << errMsg << std::endl;
        sqlite3_free(errMsg);
    } else {
        std::cout << "Table created successfully." << std::endl;
    }
}

void insertData(sqlite3* db) {
    std::string tableName;
    std::cout << "Enter table name to insert data: ";
    std::cin >> tableName;

    std::string name;
    std::cout << "Enter name to insert into table: ";
    std::cin >> name;

    std::string sql = "INSERT INTO " + tableName + " (name) VALUES ('" + name + "');";
    char* errMsg = nullptr;
    int rc = sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &errMsg);
    if (rc != SQLITE_OK) {
        std::cerr << "SQL error: " << errMsg << std::endl;
        sqlite3_free(errMsg);
    } else {
        std::cout << "Data inserted successfully." << std::endl;
    }
}

void viewTable(sqlite3* db) {
    std::string tableName;
    std::cout << "Enter table name to view data: ";
    std::cin >> tableName;

    std::string sql = "SELECT * FROM " + tableName + ";";
    sqlite3_stmt* stmt;

    int rc = sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr);
    if (rc != SQLITE_OK) {
        std::cerr << "Failed to fetch data: " << sqlite3_errmsg(db) << std::endl;
        return;
    }

    std::cout << "Data in table " << tableName << ":" << std::endl;
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        int id = sqlite3_column_int(stmt, 0);
        std::string name = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        std::cout << "ID: " << id << ", Name: " << name << std::endl;
    }

    sqlite3_finalize(stmt);
}

void deleteTable(sqlite3* db) {
    std::string tableName;
    std::cout << "Enter table name to delete: ";
    std::cin >> tableName;

    std::string sql = "DROP TABLE IF EXISTS " + tableName + ";";
    char* errMsg = nullptr;
    int rc = sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &errMsg);
    if (rc != SQLITE_OK) {
        std::cerr << "SQL error: " << errMsg << std::endl;
        sqlite3_free(errMsg);
    } else {
        std::cout << "Table deleted successfully." << std::endl;
    }
}
void viewUsers(sqlite3* db) {
    const char* sql = "SELECT username, permission FROM users;";
    sqlite3_stmt* stmt;

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        std::cerr << "Failed to fetch users: " << sqlite3_errmsg(db) << std::endl;
        return;
    }

    std::cout << "Users:" << std::endl;
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        std::string username = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
        std::string permission = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        std::cout << "Username: " << username << ", Permission: " << permission << std::endl;
    }

    sqlite3_finalize(stmt);
}
